const mongoose = require("mongoose")
const validator = require("validator")

const expertSchema = new mongoose.Schema(
    {
        first:{
            type: String,
            required: true
        },
        last:{
            type: String,
            required: true
        },
        email:{
            type: String,
            required: true,
            lowercase: true,
            validate(value){
                if(!validator.isEmail(value)){
                    throw new Error('The email inputed is not a valid email!')
                }
            }
        },
        password:{
            type: String,
            required: true,
            minlength: 8
        },
        conpassword:{
            type: String,
            required: true,
            minlength: 8
        },
        address:{
            type: String,
            required: true
        },
        mobile:{
            type: Number,
            required:true
        }
    }
)

module.exports = mongoose.model("Experts", expertSchema)