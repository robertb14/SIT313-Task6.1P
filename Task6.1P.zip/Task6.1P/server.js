//Robert Bajan 30/09/21
const { response } = require("express")
const express = require("express")
const validator = require("validator")
const bodyParser = require("body-parser")
const mongoose = require("mongoose")
const app = express()
const Expert = require("./Models/Experts.js")

app.use(express.static("Public"))
app.use(bodyParser.urlencoded({extended:true}))

mongoose.connect("mongodb://localhost:27017/iService")      //Sets up the local database

app.get('/', (req, res)=> {             //Retrieves the html file and presents in on the local server via the web browser
    res.sendFile(__dirname + "/index.html")
})

app.post('/', (req, res)=> {            //Retrieves the post from the web server
    const first = req.body.first
    const last = req.body.last
    const email = req.body.email
    const password = req.body.password
    const conpassword = req.body.conpassword
    const address = req.body.address
    const mobile = req.body.mobile

    if(!validator.equals(password, conpassword)) {
        res.status(400).send("Passwords do not match")
    }
    else {
        const NewExpert = new Expert(
        {
            first: first,
            last: last,
            email: email,
            password: password,
            conpassword: conpassword,
            address: address,
            mobile: mobile
        }
    )
        NewExpert.save((err)=>{           //Prints the data into the selected database
            if(err)
            {console.log(err)}
            else
            {console.log("Inserted Successfully")}
        })
    }
    
    res.send("I am posting now")
})

app.route('/experts')
    .get((req, res)=>{          //Retrives all items in the database
        Expert.find((err, expert) =>{
            if (err) {res.send(err)}
            else {res.send(expert)}
        })
    })

    .delete((req, res) =>{          //Deletes all items in the database
        Expert.deleteMany((err) =>{
            if (err) {res.send(err)}
            else {res.send("All Experts Have Been Successfully Deleted!")}
        })
    })


app.route('/experts/:id')
    .get((req, res) =>{         //Retrieves a specific item in the database
        Expert.findOne({_id: req.params.id}, (err, found) =>{
            if (found) (res.send(found))
            else res.send("ERROR: No matched expert found")
        })
    })

    .patch((req,res) =>{            //Updates values within a specific item in the database
        Expert.update({_id: req.params.id}, {$set: req.body}, (err) =>{
            if (!err) {res.send("Expert Successfully Updated!")}
            else res.send(err)
        }
        )
    })

    .delete((req, res) =>{          //Deletes a specific item in the database
        Expert.deleteOne({_id: req.params.id}, (err, deleted) =>{
            if (deleted) (res.send("The Expert Has Been Deleted!"))
            else res.send(err)
        })
    })
    
app.listen(3000, function (request, response) {
    console.log("Server is running on port 3000")
})